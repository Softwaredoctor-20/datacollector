import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
} from "react";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  ChevronRight,
  CircleHelp,
  Cloud,
  Crosshair,
  Droplets,
  FileText,
  Home,
  Layers3,
  LocateFixed,
  LogOut,
  MapPin,
  Menu,
  MoreHorizontal,
  Pencil,
  Plus,
  RefreshCw,
  Route,
  Settings as SettingsIcon,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  UploadCloud,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  assets,
  categories,
  defaultLookups,
  type AssetDefinition,
  type AssetField,
} from "@/config/assets";
import {
  db,
  type SurveyPhoto,
  type SurveyRecord,
} from "@/lib/db";
import { supabase } from "@/lib/supabase";

type Tab = "home" | "new" | "progress" | "queue" | "settings";
type SessionUser = { id: string; email?: string; name: string; role: string };
type LocationPoint = { latitude: number; longitude: number; accuracy: number };

const uid = (): string => crypto.randomUUID();
const formatDate = (value: string): string =>
  new Intl.DateTimeFormat("en", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(value));
const categoryLabel = (category: string): string =>
  category === "ALL"
    ? "All assets"
    : category[0] + category.slice(1).toLowerCase();

function App() {
  const [sessionUser, setSessionUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [online, setOnline] = useState(navigator.onLine);
  const [surveys, setSurveys] = useState<SurveyRecord[]>([]);
  const [surveyorName, setSurveyorName] = useState("");
  const [accuracyLimit, setAccuracyLimit] = useState(6.5);
  const [selectedAsset, setSelectedAsset] = useState<AssetDefinition | null>(
    null,
  );
  const [editingSurvey, setEditingSurvey] = useState<SurveyRecord | null>(null);
  const [lookups, setLookups] = useState(defaultLookups);
  const [showMenu, setShowMenu] = useState(false);
  const authEventVersion = useRef(0);

  const refreshSurveys = async (): Promise<void> =>
    setSurveys(await db.surveys.orderBy("capturedAt").reverse().toArray());
  useEffect(() => {
    const load = async (): Promise<void> => {
      const [{ data }, storedName, storedLimit] = await Promise.all([
        supabase.auth.getSession(),
        db.settings.get("surveyorName"),
        db.settings.get("accuracyLimit"),
      ]);
      if (data.session?.user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("full_name, role")
          .eq("id", data.session.user.id)
          .maybeSingle();
        setSessionUser({
          id: data.session.user.id,
          email: data.session.user.email,
          name: profile?.full_name || data.session.user.email || "Surveyor",
          role: profile?.role || "surveyor",
        });
      }
      setSurveyorName(storedName?.value || "");
      setAccuracyLimit(Number(storedLimit?.value || 6.5));
      await refreshSurveys();
      if (navigator.onLine) {
        const { data: rows } = await supabase
          .from("lookup_options")
          .select("list_key,value,sort")
          .order("sort");
        if (rows?.length)
          setLookups((current) =>
            rows.reduce(
              (next, row) => ({
                ...next,
                [row.list_key]: [...(next[row.list_key] || []), row.value],
              }),
              { ...current },
            ),
          );
      }
      setLoading(false);
    };
    void load();
    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        const eventVersion = ++authEventVersion.current;
        void (async () => {
          if (!session?.user) {
            setSessionUser(null);
            return;
          }
          const { data: profile } = await supabase
            .from("profiles")
            .select("full_name, role")
            .eq("id", session.user.id)
            .maybeSingle();
          if (eventVersion !== authEventVersion.current) return;
          setSessionUser({
            id: session.user.id,
            email: session.user.email,
            name: profile?.full_name || session.user.email || "Surveyor",
            role: profile?.role || "surveyor",
          });
        })();
      },
    );
    const onlineHandler = (): void => {
      setOnline(true);
      void refreshSurveys();
    };
    const offlineHandler = (): void => setOnline(false);
    window.addEventListener("online", onlineHandler);
    window.addEventListener("offline", offlineHandler);
    return () => {
      listener.subscription.unsubscribe();
      window.removeEventListener("online", onlineHandler);
      window.removeEventListener("offline", offlineHandler);
    };
  }, []);
  const queuedCount = surveys.filter(
    (survey) => survey.state === "queued",
  ).length;
  const saveSetting = async (key: string, value: string): Promise<void> => {
    await db.settings.put({ key, value });
  };
  const navigate = (tab: Tab): void => {
    setSelectedAsset(null);
    setEditingSurvey(null);
    setActiveTab(tab);
    setShowMenu(false);
  };
  const openSurvey = (survey: SurveyRecord): void => {
    const asset = assets.find((item) => item.key === survey.assetType);
    if (asset) {
      setEditingSurvey(survey);
      setSelectedAsset(asset);
      setActiveTab("new");
    }
  };
  if (loading)
    return (
      <div className="splash">
        <img src="/logo.jfif" alt="ChixyCollect" />
        <div className="loader" />
      </div>
    );
  if (!sessionUser) return <LoginScreen onSignedIn={setSessionUser} />;
  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">
            <img src="/logo.jfif" alt="" />
          </div>
          <div>
            <strong>ChixyCollect</strong>
            <span>Field survey telemetry</span>
          </div>
        </div>
        <div className="top-actions">
          <div className={`status-pill ${online ? "is-online" : "is-offline"}`}>
            <span className="status-dot" />
            {online ? "Online" : "Offline"}
          </div>
          <button className="icon-button" aria-label="Help">
            <CircleHelp size={18} />
          </button>
          <button
            className="icon-button menu-button"
            onClick={() => setShowMenu(!showMenu)}
            aria-label="Menu"
          >
            <MoreHorizontal size={20} />
          </button>
        </div>
        {showMenu && (
          <div className="quick-menu">
            <button onClick={() => navigate("settings")}>
              <SettingsIcon size={16} />
              Settings
            </button>
            <button onClick={() => navigate("queue")}>
              <UploadCloud size={16} />
              Sync queue <b>{queuedCount}</b>
            </button>
          </div>
        )}
      </header>
      <main className="content-wrap">
        {activeTab === "home" && (
          <HomeScreen
            user={sessionUser}
            online={online}
            queuedCount={queuedCount}
            surveys={surveys}
            onStart={() => navigate("new")}
            onQueue={() => navigate("queue")}
            onProgress={() => navigate("progress")}
          />
        )}
        {activeTab === "new" && !selectedAsset && (
          <NewSurveyScreen
            onSelect={(asset) => {
              setSelectedAsset(asset);
              setEditingSurvey(null);
            }}
          />
        )}
        {activeTab === "new" && selectedAsset && (
          <SurveyForm
            asset={selectedAsset}
            user={sessionUser}
            accuracyLimit={accuracyLimit}
            lookups={lookups}
            initial={editingSurvey}
            defaultSurveyor={surveyorName}
            onBack={() => {
              setSelectedAsset(null);
              setEditingSurvey(null);
            }}
            onSaved={async () => {
              await refreshSurveys();
              setActiveTab("queue");
              setSelectedAsset(null);
              setEditingSurvey(null);
            }}
          />
        )}
        {activeTab === "progress" && (
          <ProgressScreen
            surveys={surveys}
            online={online}
            user={sessionUser}
          />
        )}
        {activeTab === "queue" && (
          <QueueScreen
            surveys={surveys}
            online={online}
            refresh={refreshSurveys}
            user={sessionUser}
            onEdit={openSurvey}
          />
        )}
        {activeTab === "settings" && (
          <SettingsScreen
            user={sessionUser}
            surveyorName={surveyorName}
            accuracyLimit={accuracyLimit}
            surveyCount={surveys.length}
            saveSetting={saveSetting}
            setSurveyorName={setSurveyorName}
            setAccuracyLimit={setAccuracyLimit}
            onSignOut={() => void supabase.auth.signOut()}
          />
        )}
      </main>
      <nav className="bottom-nav">
        {[
          ["home", Home, "Home"],
          ["new", Plus, "New survey"],
          ["progress", Activity, "Progress"],
          ["queue", UploadCloud, "Queue"],
          ["settings", SettingsIcon, "Settings"],
        ].map(([key, Icon, label]) => (
          <button
            key={key as string}
            className={activeTab === key ? "active" : ""}
            onClick={() => navigate(key as Tab)}
          >
            <span className="nav-icon">
              <Icon size={19} />
              {key === "queue" && queuedCount > 0 && <em>{queuedCount}</em>}
            </span>
            <span>{label as string}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

function LoginScreen({
  onSignedIn,
}: {
  onSignedIn: (user: SessionUser) => void;
}) {
  const [mode, setMode] = useState<"sign-in" | "sign-up">("sign-in");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent): Promise<void> => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      if (mode === "sign-up") {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { full_name: fullName.trim() } },
        });
        if (signUpError) {
          setError(signUpError.message);
        } else if (data.session && data.user) {
          onSignedIn({
            id: data.user.id,
            email: data.user.email,
            name: fullName.trim() || data.user.email || "Surveyor",
            role: "surveyor",
          });
        } else {
          setError(
            "Signup did not create a session. Turn off Confirm email in Supabase, and check whether this account already exists.",
          );
        }
      } else {
        const { data, error: signInError } =
          await supabase.auth.signInWithPassword({
            email: email.trim(),
            password,
          });
        if (signInError || !data.user) {
          setError(signInError?.message || "Unable to sign in.");
        } else {
          onSignedIn({
            id: data.user.id,
            email: data.user.email,
            name: data.user.email || "Surveyor",
            role: "surveyor",
          });
        }
      }
    } catch (authError) {
      setError(
        authError instanceof Error ? authError.message : "Authentication failed.",
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="auth-page">
      <div className="auth-art">
        <div className="auth-orb" />
        <img src="/logo.jfif" alt="Zimbabwe coat of arms" />
        <p>
          Official mobile survey repository for roads, bridges and
          infrastructure telemetry.
        </p>
        <div className="auth-note">
          <ShieldCheck size={17} /> Secure. Offline-capable. Built for the
          field.
        </div>
      </div>
      <div className="auth-card">
        <span className="eyebrow">CHIXYCOLLECT</span>
        <h1>{mode === "sign-up" ? "Create your account" : "Welcome back"}</h1>
        <p className="muted">
          {mode === "sign-up"
            ? "Register to save and sync your field surveys."
            : "Sign in to continue your survey work."}
        </p>
        <form onSubmit={submit}>
          {mode === "sign-up" && (
            <label>
              Full name
              <input
                type="text"
                value={fullName}
                onChange={(event) => setFullName(event.target.value)}
                autoComplete="name"
                required
              />
            </label>
          )}
          <label>
            Email address
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              autoComplete="email"
              required
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete={mode === "sign-up" ? "new-password" : "current-password"}
              minLength={mode === "sign-up" ? 8 : undefined}
              required
            />
          </label>
          {error && <div className="form-error">{error}</div>}
          <button className="primary-button wide" disabled={busy}>
            {busy
              ? mode === "sign-up"
                ? "Creating account…"
                : "Signing in…"
              : mode === "sign-up"
                ? "Create account"
                : "Sign in"}
            <ArrowRight size={17} />
          </button>
        </form>
        <p className="auth-foot">
          {mode === "sign-up" ? "Already have an account? " : "New to ChixyCollect? "}
          <button
            type="button"
            className="auth-toggle"
            onClick={() => {
              setMode(mode === "sign-up" ? "sign-in" : "sign-up");
              setError("");
            }}
          >
            {mode === "sign-up" ? "Sign in" : "Create an account"}
          </button>
        </p>
      </div>
    </div>
  );
}

function HomeScreen({
  user,
  online,
  queuedCount,
  surveys,
  onStart,
  onQueue,
  onProgress,
}: {
  user: SessionUser;
  online: boolean;
  queuedCount: number;
  surveys: SurveyRecord[];
  onStart: () => void;
  onQueue: () => void;
  onProgress: () => void;
}) {
  const drafts = surveys.filter((survey) => survey.state === "draft").length;
  const synced = surveys.filter((survey) => survey.state === "synced").length;
  return (
    <section>
      <div className="page-intro">
        <div>
          <span className="eyebrow">FIELD DASHBOARD</span>
          <h1>Good morning, {user.name.split(" ")[0]}</h1>
          <p>Ready to keep the network moving?</p>
        </div>
        <div className="avatar">{user.name.slice(0, 1)}</div>
      </div>
      <div className="motid-hero">
        <img src="/logo.jfif" alt="" />
        <div>
          <span>CHIXYCOLLECT</span>
          <strong>National infrastructure telemetry</strong>
          <small>Capture accurate, field-ready asset intelligence.</small>
        </div>
      </div>
      <div className="shortcut-grid">
        <button onClick={onProgress}>
          <Activity size={18} />
          <span>
            <strong>My progress</strong>
            <small>
              {synced} synced · {surveys.length} total
            </small>
          </span>
          <ChevronRight size={16} />
        </button>
        <button onClick={onQueue}>
          <FileText size={18} />
          <span>
            <strong>Draft queue</strong>
            <small>
              {drafts} in progress · {queuedCount} ready
            </small>
          </span>
          <ChevronRight size={16} />
        </button>
      </div>
      <button className="hero-action" onClick={onStart}>
        <div className="hero-icon">
          <Plus size={25} />
        </div>
        <div>
          <strong>Start new survey</strong>
          <span>Capture a road or infrastructure asset</span>
        </div>
        <ArrowRight size={21} />
      </button>
      <div className="profile-card">
        <div className="profile-icon">
          <ShieldCheck size={21} />
        </div>
        <div>
          <span className="eyebrow">SURVEYOR INFORMATION</span>
          <strong>{user.name}</strong>
          <span>
            {user.role} ·{" "}
            {online ? "Online (Connected)" : "Offline (data is safe)"}
          </span>
        </div>
        <ChevronRight size={18} />
      </div>
      <div className="guide-card">
        <div className="tip-icon">
          <Sparkles size={18} />
        </div>
        <div>
          <strong>Field operation guide</strong>
          <p>
            Keep GPS accuracy under the limit. High-precision tracking adds
            points automatically. Finish drafts before syncing.
          </p>
        </div>
      </div>
    </section>
  );
}

function NewSurveyScreen({
  onSelect,
}: {
  onSelect: (asset: AssetDefinition) => void;
}) {
  const [filter, setFilter] = useState("ALL");
  const visible =
    filter === "ALL"
      ? assets
      : assets.filter((asset) => asset.category === filter);
  const iconFor = (asset: AssetDefinition): JSX.Element =>
    asset.geometry === "line" ? (
      <Route size={23} />
    ) : asset.category === "DRAINAGE" ? (
      <Droplets size={23} />
    ) : asset.category === "TRAFFIC" ? (
      <Crosshair size={23} />
    ) : asset.category === "AMENITIES" ? (
      <MapPin size={23} />
    ) : (
      <Layers3 size={23} />
    );
  return (
    <section>
      <div className="page-intro">
        <div>
          <span className="eyebrow">NEW SURVEY</span>
          <h1>Choose an asset</h1>
          <p>Select the asset you are inspecting today.</p>
        </div>
        <div className="round-icon">
          <Menu size={19} />
        </div>
      </div>
      <div className="filter-row">
        {categories.map((category) => (
          <button
            key={category}
            className={filter === category ? "selected" : ""}
            onClick={() => setFilter(category)}
          >
            {categoryLabel(category)}
            <span>
              {category === "ALL"
                ? assets.length
                : assets.filter((asset) => asset.category === category).length}
            </span>
          </button>
        ))}
      </div>
      <div className="asset-list">
        {visible.map((asset) => (
          <button
            className="asset-card"
            key={asset.key}
            onClick={() => onSelect(asset)}
          >
            <div className={`asset-icon ${asset.category.toLowerCase()}`}>
              {iconFor(asset)}
            </div>
            <div className="asset-copy">
              <div className="asset-heading">
                <strong>{asset.label}</strong>
                <span>{asset.category}</span>
              </div>
              <p>{asset.description}</p>
            </div>
            <ChevronRight size={18} />
          </button>
        ))}
      </div>
      <div className="offline-note">
        <Wifi size={16} />
        <span>
          Forms, GPS points and photos stay on this device until you sync.
        </span>
      </div>
    </section>
  );
}

function SurveyForm({
  asset,
  user,
  accuracyLimit,
  lookups,
  initial,
  defaultSurveyor,
  onBack,
  onSaved,
}: {
  asset: AssetDefinition;
  user: SessionUser;
  accuracyLimit: number;
  lookups: Record<string, string[]>;
  initial: SurveyRecord | null;
  defaultSurveyor: string;
  onBack: () => void;
  onSaved: () => Promise<void>;
}) {
  const defaultProps = asset.fields.reduce<
    Record<string, string | number | string[]>
  >((defaults, field) => {
    if (field.defaultValue !== undefined)
      defaults[field.key] = field.defaultValue;
    return defaults;
  }, {});
  const [highwayRoute, setHighwayRoute] = useState(initial?.highwayRoute || "");
  const [sectionName, setSectionName] = useState(initial?.sectionName || "");
  const [recordId, setRecordId] = useState(() => initial?.id || uid());
  const [capturedAt, setCapturedAt] = useState(
    () => initial?.capturedAt || new Date().toISOString(),
  );
  const [surveyor, setSurveyor] = useState(
    initial?.surveyorName || defaultSurveyor || user.name,
  );
  const [vegetation, setVegetation] = useState(
    initial?.vegetationStatus || "Medium",
  );
  const [sadc, setSadc] = useState(initial?.sadcCompliant || "Yes (Compliant)");
  const [props, setProps] = useState<
    Record<string, string | number | string[]>
  >({ ...defaultProps, ...(initial?.props || {}) });
  const [notes, setNotes] = useState(initial?.props.notes?.toString() || "");
  const [location, setLocation] = useState<LocationPoint | null>(
    initial?.geometry?.type === "Point"
      ? {
          latitude: Number((initial.geometry.coordinates as number[])[1]),
          longitude: Number((initial.geometry.coordinates as number[])[0]),
          accuracy: initial.accuracy || 99,
        }
      : null,
  );
  const [linePoints, setLinePoints] = useState<number[][]>(
    initial?.geometry?.type === "LineString"
      ? (initial.geometry.coordinates as number[][])
      : [],
  );
  const [bestAccuracy, setBestAccuracy] = useState(initial?.accuracy || 99);
  const [locating, setLocating] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordMode, setRecordMode] = useState<"Auto" | "Manual">("Auto");
  const [collectionMode, setCollectionMode] = useState(
    initial?.collectionMode || "Single road",
  );
  const [snapping, setSnapping] = useState(initial?.snapping ?? true);
  const [capturedLocation, setCapturedLocation] = useState<LocationPoint | null>(
    initial?.geometry?.type === "Point"
      ? {
          latitude: Number((initial.geometry.coordinates as number[])[1]),
          longitude: Number((initial.geometry.coordinates as number[])[0]),
          accuracy: initial.accuracy || 99,
        }
      : null,
  );
  const [photos, setPhotos] = useState<SurveyPhoto[]>(initial?.photos || []);
  const [status, setStatus] = useState("");
  const [recoveryDraft, setRecoveryDraft] = useState<SurveyRecord | null>(null);
  const [recoveryChecked, setRecoveryChecked] = useState(false);
  const watchRef = useRef<number | null>(null);
  const intervalRef = useRef<number | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const initialAutosaveSkipped = useRef(false);
  const skipNextAutosave = useRef(false);
  const latestRef = useRef<LocationPoint | null>(location);
  const isRoad = asset.geometry === "line";
  const activeDraftKey = `activeSurvey:${asset.key}`;
  const maxSegmentLength = asset.key === "gravel_road" ? 500 : 5000;
  const currentPoint = location && location.accuracy <= accuracyLimit;
  const validFields = asset.fields.every((field) => {
    const value = props[field.key];
    return (
      !field.required ||
      (Array.isArray(value)
        ? value.length > 0
        : value !== undefined && value !== "")
    );
  });
  const segmentLength = isRoad ? lineLength(linePoints) : 0;
  const validGeometry = isRoad
    ? linePoints.length >= 2 && segmentLength > 0 && segmentLength <= maxSegmentLength
    : Boolean(capturedLocation);
  const canSaveDraft = !isRoad || validGeometry;
  const canQueue = Boolean(
    highwayRoute &&
    sectionName &&
    surveyor &&
    vegetation &&
    sadc &&
    validFields &&
    validGeometry,
  );
  const updateLocation = (point: LocationPoint): void => {
    latestRef.current = point;
    setLocation(point);
    setBestAccuracy((current) => Math.min(current, point.accuracy));
    if (
      recording &&
      isRoad &&
      (recordMode === "Manual" ? false : true) &&
      point.accuracy <= accuracyLimit
    )
      setLinePoints((points) => [...points, [point.longitude, point.latitude]]);
  };
  const startWatch = (): void => {
    if (!navigator.geolocation) {
      setStatus("Location is not available on this device.");
      return;
    }
    setLocating(true);
    const id = navigator.geolocation.watchPosition(
      (position) => {
        setLocating(false);
        updateLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
      },
      () => {
        setLocating(false);
        setStatus("Could not read your location. Check device permissions.");
      },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 },
    );
    watchRef.current = id;
  };
  const stopWatch = (): void => {
    if (watchRef.current !== null)
      navigator.geolocation.clearWatch(watchRef.current);
    watchRef.current = null;
  };
  useEffect(() => {
    startWatch();
    return () => {
      stopWatch();
      if (intervalRef.current !== null)
        window.clearInterval(intervalRef.current);
      if (wakeLockRef.current) void wakeLockRef.current.release();
    };
  }, []);
  const startRecording = (): void => {
    setRecording(true);
    if ("wakeLock" in navigator)
      void navigator.wakeLock
        .request("screen")
        .then((wakeLock) => {
          wakeLockRef.current = wakeLock;
        })
        .catch(() => undefined);
    if (recordMode === "Auto")
      intervalRef.current = window.setInterval(() => {
        const point = latestRef.current;
        if (point && point.accuracy <= accuracyLimit)
          setLinePoints((points) => [
            ...points,
            [point.longitude, point.latitude],
          ]);
      }, 3000);
  };
  const stopRecording = (): void => {
    setRecording(false);
    if (intervalRef.current !== null) window.clearInterval(intervalRef.current);
    intervalRef.current = null;
    if (wakeLockRef.current) {
      void wakeLockRef.current.release();
      wakeLockRef.current = null;
    }
  };
  const setField = (
    field: AssetField,
    value: string | number | string[],
  ): void => setProps((current) => ({ ...current, [field.key]: value }));
  const buildRecord = (state: "draft" | "queued"): SurveyRecord => ({
    id: recordId,
    assetType: asset.key,
    state,
    highwayRoute,
    sectionName,
    surveyorName: surveyor,
    vegetationStatus: vegetation,
    sadcCompliant: sadc,
    props: { ...props, notes },
    notes,
    geometry: isRoad
      ? linePoints.length >= 2
        ? { type: "LineString", coordinates: linePoints }
        : null
      : capturedLocation
        ? {
            type: "Point",
            coordinates: [capturedLocation.longitude, capturedLocation.latitude],
          }
        : null,
    accuracy: bestAccuracy < 99 ? bestAccuracy : null,
    capturedAt,
    photos,
    collectionMode,
    snapping,
    chainageFromKm:
      props.chainage_from_km === undefined || props.chainage_from_km === ""
        ? undefined
        : Number(props.chainage_from_km),
    chainageToKm:
      props.chainage_to_km === undefined || props.chainage_to_km === ""
        ? undefined
        : Number(props.chainage_to_km),
  });
  useEffect(() => {
    let mounted = true;
    if (initial) {
      setRecoveryChecked(true);
      return () => {
        mounted = false;
      };
    }
    void db.settings.get(activeDraftKey).then((stored) => {
      if (!mounted) return;
      if (stored) {
        try {
          const candidate = JSON.parse(stored.value) as SurveyRecord;
          if (candidate.id !== recordId) setRecoveryDraft(candidate);
        } catch {
          void db.settings.delete(activeDraftKey);
        }
      }
      setRecoveryChecked(true);
    });
    return () => {
      mounted = false;
    };
  }, [activeDraftKey, initial, recordId]);
  useEffect(() => {
    if (!recoveryChecked || recoveryDraft) return;
    if (!initialAutosaveSkipped.current) {
      initialAutosaveSkipped.current = true;
      return;
    }
    if (skipNextAutosave.current) {
      skipNextAutosave.current = false;
      return;
    }
    void db.settings.put({
      key: activeDraftKey,
      value: JSON.stringify(buildRecord("draft")),
    });
  }, [
    activeDraftKey,
    bestAccuracy,
    buildRecord,
    capturedAt,
    capturedLocation,
    collectionMode,
    highwayRoute,
    initial,
    linePoints,
    notes,
    photos,
    props,
    recoveryChecked,
    recoveryDraft,
    sadc,
    snapping,
    sectionName,
    surveyor,
    vegetation,
  ]);
  const resumeRecovery = (): void => {
    if (!recoveryDraft) return;
    const draft = recoveryDraft;
    setRecordId(draft.id);
    setCapturedAt(draft.capturedAt);
    setHighwayRoute(draft.highwayRoute);
    setSectionName(draft.sectionName);
    setSurveyor(draft.surveyorName);
    setVegetation(draft.vegetationStatus);
    setSadc(draft.sadcCompliant);
    setProps(draft.props);
    setNotes(draft.notes);
    setLinePoints(
      draft.geometry?.type === "LineString"
        ? (draft.geometry.coordinates as number[][])
        : [],
    );
    setCapturedLocation(
      draft.geometry?.type === "Point"
        ? {
            latitude: Number((draft.geometry.coordinates as number[])[1]),
            longitude: Number((draft.geometry.coordinates as number[])[0]),
            accuracy: draft.accuracy || 99,
          }
        : null,
    );
    setLocation(
      draft.geometry?.type === "Point"
        ? {
            latitude: Number((draft.geometry.coordinates as number[])[1]),
            longitude: Number((draft.geometry.coordinates as number[])[0]),
            accuracy: draft.accuracy || 99,
          }
        : location,
    );
    setBestAccuracy(draft.accuracy || 99);
    setPhotos(draft.photos);
    setCollectionMode(draft.collectionMode || "Single road");
    setSnapping(draft.snapping ?? true);
    setRecoveryDraft(null);
    setStatus("Unsaved survey restored.");
  };
  const discardRecovery = (): void => {
    skipNextAutosave.current = true;
    void db.settings.delete(activeDraftKey);
    setRecoveryDraft(null);
    setRecordId(uid());
    setCapturedAt(new Date().toISOString());
  };
  const addPhotos = (event: ChangeEvent<HTMLInputElement>): void => {
    const files = Array.from(event.target.files || []).slice(
      0,
      (isRoad ? 6 : 2) - photos.length,
    );
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () =>
        setPhotos((current) => [
          ...current,
          { id: uid(), dataUrl: String(reader.result), name: file.name },
        ]);
      reader.readAsDataURL(file);
    });
    event.target.value = "";
  };
  const save = async (state: "draft" | "queued"): Promise<void> => {
    if (state === "queued" && !canQueue) return;
    const record = buildRecord(state);
    await db.surveys.put(record);
    await db.settings.delete(activeDraftKey);
    setStatus(
      state === "queued"
        ? "Survey added to the sync queue."
        : "Auto-saved draft on this device.",
    );
    if (state === "queued") await onSaved();
  };
  return (
    <section>
      <div className="form-title">
        <button className="back-link" onClick={onBack}>
          <ArrowLeft size={14} /> Back to Selection
        </button>
        <h1>{asset.label}</h1>
        <span className="autosave-badge">
          <Check size={12} /> Auto-saved
        </span>
      </div>
      {recoveryDraft && (
        <div className="recovery-banner">
          <div>
            <strong>Unsaved Survey Found</strong>
            <span>Resume your saved {asset.label.toLowerCase()} survey?</span>
          </div>
          <button className="secondary-button" onClick={resumeRecovery}>
            Resume
          </button>
          <button className="outline-button" onClick={discardRecovery}>
            Discard
          </button>
        </div>
      )}
      <div className="form-card">
        {isRoad && (
          <div className="form-section road-photo-section">
            <div className="form-section-title">
              <span>01</span>
              <div>
                <h2>Road photos</h2>
                <p>Attach images of the road surface and defects.</p>
              </div>
            </div>
            <PhotoCaptureControl
              photos={photos}
              isRoad={isRoad}
              onChange={addPhotos}
              onRemove={(photoId) =>
                setPhotos((current) => current.filter((photo) => photo.id !== photoId))
              }
            />
          </div>
        )}
        <div className="form-section">
          <div className="form-section-title">
            <span>01</span>
            <div>
              <h2>Survey context</h2>
              <p>Identify the route and survey location.</p>
            </div>
          </div>
          <div className="field-grid">
            <label>
              Highway route
              <input
                value={highwayRoute}
                onChange={(event) => setHighwayRoute(event.target.value)}
                placeholder="e.g. A5 Harare Road"
              />
            </label>
            <label>
              Section name
              <input
                value={sectionName}
                onChange={(event) => setSectionName(event.target.value)}
                placeholder="e.g. Ward 5"
              />
            </label>
            <label>
              Surveyor name
              <input
                value={surveyor}
                onChange={(event) => setSurveyor(event.target.value)}
              />
            </label>
            {isRoad && (
              <>
                <label>
                  Collection mode
                  <select
                    value={collectionMode}
                    onChange={(event) => setCollectionMode(event.target.value)}
                  >
                    <option>Single road</option>
                    <option>Multiple segments</option>
                  </select>
                </label>
                <label>
                  Chainage from (km)
                  <input
                    type="number"
                    value={String(props.chainage_from_km ?? "")}
                    onChange={(event) =>
                      setField(
                        {
                          key: "chainage_from_km",
                          label: "Chainage from",
                          type: "number",
                        },
                        event.target.value === ""
                          ? ""
                          : Number(event.target.value),
                      )
                    }
                  />
                </label>
                <label>
                  Chainage to (km)
                  <input
                    type="number"
                    value={String(props.chainage_to_km ?? "")}
                    onChange={(event) =>
                      setField(
                        {
                          key: "chainage_to_km",
                          label: "Chainage to",
                          type: "number",
                        },
                        event.target.value === ""
                          ? ""
                          : Number(event.target.value),
                      )
                    }
                  />
                </label>
              </>
            )}
          </div>
        </div>
        <div className="form-section">
          <div className="form-section-title">
            <span>02</span>
            <div>
              <h2>Common observations</h2>
              <p>Required context captured on every asset.</p>
            </div>
          </div>
          <div className="field-grid">
            <SelectField
              label="Vegetation status"
              value={vegetation}
              options={
                lookups.vegetation_status || defaultLookups.vegetation_status
              }
              onChange={setVegetation}
            />
            <SelectField
              label="SADC sign compliant"
              value={sadc}
              options={lookups.sadc_compliant || defaultLookups.sadc_compliant}
              onChange={setSadc}
            />
          </div>
        </div>
        {isRoad && (
          <RoadRecorder
            recording={recording}
            assetKey={asset.key}
            recordMode={recordMode}
            setRecordMode={setRecordMode}
            snapping={snapping}
            setSnapping={setSnapping}
            startRecording={startRecording}
            stopRecording={stopRecording}
            addPoint={() => {
              const point = latestRef.current;
              if (point && point.accuracy <= accuracyLimit)
                setLinePoints((points) => [
                  ...points,
                  [point.longitude, point.latitude],
                ]);
            }}
            undo={() => setLinePoints((points) => points.slice(0, -1))}
            points={linePoints}
            segmentLength={segmentLength}
            maxSegmentLength={maxSegmentLength}
            accuracy={location?.accuracy || null}
            limit={accuracyLimit}
            photoCount={photos.length}
            onSnapPhoto={addPhotos}
          />
        )}
        {!isRoad && (
          <div className="form-section">
            <div className="form-section-title">
              <span>03</span>
              <div>
                <h2>Asset attributes</h2>
                <p>Complete all required fields before queueing.</p>
              </div>
            </div>
            <div className="field-grid">
              {asset.fields.map((field) => (
                <DynamicField
                  key={field.key}
                  field={field}
                  value={props[field.key]}
                  options={
                    field.options ||
                    lookups[field.list || ""] ||
                    defaultLookups[field.list || ""] || ["Option 1", "Option 2"]
                  }
                  setField={setField}
                  disabled={
                    field.key === "box_size_m2" &&
                    props.causeway_type === "Piped"
                  }
                />
              ))}
            </div>
          </div>
        )}
        {isRoad && (
          <div className="form-section">
            <div className="form-section-title">
              <span>04</span>
              <div>
                <h2>Road attributes</h2>
                <p>
                  {linePoints.length >= 2
                    ? "Segment recorded. Complete the unlocked form."
                    : "Record a GPS segment above to unlock attributes."}
                </p>
              </div>
            </div>
            <div className="field-grid">
              {asset.fields.map((field) => (
                <DynamicField
                  key={field.key}
                  field={field}
                  value={props[field.key]}
                  options={
                    field.options ||
                    lookups[field.list || ""] ||
                    defaultLookups[field.list || ""] || ["Option 1", "Option 2"]
                  }
                  setField={setField}
                  disabled={linePoints.length < 2}
                />
              ))}
            </div>
          </div>
        )}
        <div className="form-section">
          <div className="form-section-title">
            <span>{isRoad ? "05" : "04"}</span>
            <div>
              <h2>GPS telemetry & photos</h2>
              <p>
                Best accuracy ±
                {bestAccuracy < 99 ? bestAccuracy.toFixed(1) : "—"} m · need ≤
                {accuracyLimit} m
              </p>
            </div>
          </div>
          {!isRoad && (
            <div className={`gps-card ${currentPoint ? "accurate" : ""}`}>
              <div className="gps-main">
                <div className="gps-pulse">
                  <LocateFixed size={20} />
                </div>
                <div>
                  <strong>
                    {location
                      ? `±${location.accuracy.toFixed(1)} m — ${currentPoint ? (location.accuracy <= 3 ? "Excellent" : "Good") : "Improving…"}`
                      : locating
                        ? "Acquiring GPS…"
                        : "Waiting for GPS"}
                  </strong>
                  <span>
                    {location
                      ? `${location.latitude.toFixed(5)}, ${location.longitude.toFixed(5)} · ${currentPoint ? "Location locked" : `need ≤${accuracyLimit}m`}`
                      : "Stand outdoors with a clear sky"}
                  </span>
                </div>
              </div>
              <div className="gps-actions">
                <span className="gps-quality">
                  {capturedLocation ? "GPS point captured" : "Capture required"}
                </span>
                <button
                  className="primary-button"
                  disabled={!currentPoint}
                  onClick={() => {
                    if (latestRef.current && latestRef.current.accuracy <= accuracyLimit)
                      setCapturedLocation(latestRef.current);
                  }}
                >
                  <LocateFixed size={15} /> Capture GPS
                </button>
                <button className="outline-button" onClick={startWatch}>
                  <RefreshCw size={15} /> Refresh
                </button>
              </div>
            </div>
          )}
          {!isRoad && (
            <PhotoCaptureControl
              photos={photos}
              isRoad={isRoad}
              onChange={addPhotos}
              onRemove={(photoId) =>
                setPhotos((current) => current.filter((photo) => photo.id !== photoId))
              }
            />
          )}
          <label>
            Notes
            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Anything else the review team should know?"
            />
          </label>
        </div>
      </div>
      {status && (
        <div className="success-line">
          <Check size={16} />
          {status}
        </div>
      )}
      {isRoad && !canSaveDraft && (
        <p className="segment-requirement">
          Complete at least one segment (GPS + attributes) to save or queue.
        </p>
      )}
      <div className="form-actions">
        <button
          className="secondary-button"
          disabled={!canSaveDraft}
          onClick={() => void save("draft")}
        >
          Save draft
        </button>
        <button
          className="primary-button"
          disabled={!canQueue}
          onClick={() => void save("queued")}
        >
          Queue for sync <UploadCloud size={17} />
        </button>
      </div>
    </section>
  );
}

function PhotoCaptureControl({
  photos,
  isRoad,
  onChange,
  onRemove,
}: {
  photos: SurveyPhoto[];
  isRoad: boolean;
  onChange: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemove: (photoId: string) => void;
}) {
  return (
    <>
      <label className="photo-drop">
        <Camera size={20} />
        <span>
          <strong>
            Add photo ({photos.length}/{isRoad ? 6 : 2})
          </strong>
          <small>Use your camera or choose from this device</small>
        </span>
        <input
          type="file"
          accept="image/*"
          multiple={isRoad}
          capture="environment"
          disabled={photos.length >= (isRoad ? 6 : 2)}
          onChange={onChange}
        />
      </label>
      {photos.length > 0 && (
        <div className="photo-strip">
          {photos.map((photo) => (
            <div key={photo.id}>
              <img src={photo.dataUrl} alt={photo.name} />
              <button onClick={() => onRemove(photo.id)} aria-label="Remove photo">
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function SelectField({
  label,
  value,
  options,
  onChange,
  disabled = false,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  return (
    <label>
      {label}
      <select
        value={value}
        disabled={disabled}
        onChange={(event) => onChange(event.target.value)}
      >
        <option value="">Select {label.toLowerCase()}</option>
        {options.map((option) => (
          <option key={option}>{option}</option>
        ))}
      </select>
    </label>
  );
}
function DynamicField({
  field,
  value,
  options,
  setField,
  disabled = false,
}: {
  field: AssetField;
  value: string | number | string[] | undefined;
  options: string[];
  setField: (field: AssetField, value: string | number | string[]) => void;
  disabled?: boolean;
}) {
  if (field.type === "multiselect")
    return (
      <div className="multi-field">
        <span>{field.label}</span>
        <div>
          {options.map((option) => {
            const selected = Array.isArray(value) && value.includes(option);
            return (
              <label key={option} className="check-option">
                <input
                  type="checkbox"
                  disabled={disabled}
                  checked={selected}
                  onChange={() =>
                    setField(
                      field,
                      selected
                        ? (value as string[]).filter((item) => item !== option)
                        : [...(Array.isArray(value) ? value : []), option],
                    )
                  }
                />
                {option}
              </label>
            );
          })}
        </div>
      </div>
    );
  if (field.type === "select")
    return (
      <SelectField
        label={field.label}
        value={String(value ?? field.defaultValue ?? "")}
        options={options}
        disabled={disabled}
        onChange={(next) => setField(field, next)}
      />
    );
  if (field.type === "textarea")
    return (
      <label>
        {disabled ? `${field.label} (N/A for piped)` : field.label}
        <textarea
          disabled={disabled}
          value={String(value ?? "")}
          onChange={(event) => setField(field, event.target.value)}
        />
      </label>
    );
  return (
    <label>
      {disabled ? `${field.label} (N/A for piped)` : field.label}
      {field.unit && <small className="unit">({field.unit})</small>}
      <input
        disabled={disabled}
        type={field.type === "text" ? "text" : "number"}
        min={field.min}
        max={field.max}
        step={field.type === "integer" ? 1 : "any"}
        value={String(value ?? "")}
        placeholder={field.placeholder}
        onChange={(event) =>
          setField(
            field,
            field.type === "text"
              ? event.target.value
              : Number(event.target.value),
          )
        }
      />
    </label>
  );
}

function RoadRecorder({
  recording,
  assetKey = "sealed_road",
  recordMode,
  setRecordMode,
  snapping = true,
  setSnapping = () => undefined,
  startRecording,
  stopRecording,
  addPoint,
  undo,
  points,
  segmentLength = 0,
  maxSegmentLength = 5000,
  accuracy,
  limit,
  photoCount = 0,
  onSnapPhoto = () => undefined,
}: {
  recording: boolean;
  assetKey?: string;
  recordMode: "Auto" | "Manual";
  setRecordMode: (mode: "Auto" | "Manual") => void;
  snapping?: boolean;
  setSnapping?: (enabled: boolean) => void;
  startRecording: () => void;
  stopRecording: () => void;
  addPoint: () => void;
  undo: () => void;
  points: number[][];
  segmentLength?: number;
  maxSegmentLength?: number;
  accuracy: number | null;
  limit: number;
  photoCount?: number;
  onSnapPhoto?: (event: ChangeEvent<HTMLInputElement>) => void;
}) {
  const photoInputRef = useRef<HTMLInputElement>(null);
  const outdoorGuidance = ["gravel_road", "earth_road"].includes(assetKey);
  return (
    <div className="record-card">
      <div className="record-heading">
        <div className="record-icon">
          <Route size={19} />
        </div>
        <div>
          <h2>GPS line survey</h2>
          <p>
            {outdoorGuidance
              ? "Record segment geometry before entering attributes."
              : "High-precision tracking · keep the screen awake"}
          </p>
        </div>
        <span className={`record-status ${recording ? "live" : ""}`}>
          <span />
          {recording ? "Recording" : "Ready"}
        </span>
      </div>
      <div className="record-controls">
        <label>
          Recording mode
          <select
            value={recordMode}
            onChange={(event) =>
              setRecordMode(event.target.value as "Auto" | "Manual")
            }
          >
            <option>Auto</option>
            <option>Manual</option>
          </select>
        </label>
        <div className="record-stat">
          <strong>{points.length}</strong>
          <span>vertices</span>
        </div>
        <div className="record-stat">
          <strong>{accuracy ? `±${accuracy.toFixed(1)}` : "—"}</strong>
          <span>GPS metres</span>
        </div>
        <div className="record-stat">
          <strong>{segmentLength.toFixed(0)} m</strong>
          <span>of {maxSegmentLength} m max</span>
        </div>
      </div>
      <button
        className={`snapping-toggle ${snapping ? "enabled" : ""}`}
        type="button"
        aria-pressed={snapping}
        onClick={() => setSnapping(!snapping)}
      >
        <Crosshair size={15} /> Road snapping {snapping ? "ON" : "OFF"}
      </button>
      <div className="record-note">
        <Zap size={15} />
        {outdoorGuidance
          ? "Operate outdoors under clear skies for sub-7m accuracy."
          : `Auto mode adds a point every 3 seconds when accuracy is ≤${limit} m.`}
      </div>
      <div className="record-actions">
        {!recording ? (
          <button className="primary-button" onClick={startRecording}>
            <LocateFixed size={16} /> Start segment recording
          </button>
        ) : (
          <>
            <input
              ref={photoInputRef}
              className="visually-hidden"
              type="file"
              accept="image/*"
              capture="environment"
              onChange={onSnapPhoto}
            />
            <button
              className="secondary-button"
              type="button"
              disabled={photoCount >= 6}
              onClick={() => photoInputRef.current?.click()}
            >
              <Camera size={16} /> Snap Road Photo
            </button>
            <button
              className="secondary-button"
              onClick={addPoint}
              disabled={recordMode !== "Manual"}
            >
              <Plus size={16} /> Add point now
            </button>
            <button
              className="outline-button"
              onClick={undo}
              disabled={!points.length}
            >
              Undo
            </button>
            <button className="secondary-button stop" onClick={stopRecording}>
              Stop recording
            </button>
          </>
        )}
      </div>
      {points.length > 0 && (
        <p className="record-summary">
          {points.length < 2
            ? "Add at least one more point to finish this segment."
            : "Segment captured. Road attributes are now unlocked."}
        </p>
      )}
    </div>
  );
}

function QueueScreen({
  surveys,
  online,
  refresh,
  user,
  onEdit,
}: {
  surveys: SurveyRecord[];
  online: boolean;
  refresh: () => Promise<void>;
  user: SessionUser;
  onEdit: (survey: SurveyRecord) => void;
}) {
  const [tab, setTab] = useState<"draft" | "queued">("draft");
  const items = surveys.filter((survey) => survey.state === tab);
  const [syncing, setSyncing] = useState(false);
  const sync = async (): Promise<void> => {
    if (!online || !items.length) return;
    setSyncing(true);
    for (const survey of items) {
      if (!survey.geometry) continue;
      const uploadedPhotos: Array<{ id: string; name: string; path: string }> = [];
      let photoUploadError = "";
      for (const photo of survey.photos) {
        try {
          const image = await fetch(photo.dataUrl).then((response) =>
            response.blob(),
          );
          const path = `${user.id}/${survey.id}/${photo.id}`;
          const { error } = await supabase.storage
            .from("survey-photos")
            .upload(path, image, {
              contentType: image.type || "application/octet-stream",
              upsert: true,
            });
          if (error) throw error;
          uploadedPhotos.push({ id: photo.id, name: photo.name, path });
        } catch (uploadError) {
          photoUploadError =
            uploadError instanceof Error
              ? uploadError.message
              : "Photo upload failed.";
          break;
        }
      }
      if (photoUploadError) {
        await db.surveys.update(survey.id, { lastError: photoUploadError });
        continue;
      }
      const { error } = await supabase.rpc("upsert_survey", {
        p: {
          id: survey.id,
          asset_type: survey.assetType,
          geometry: survey.geometry,
          gps_accuracy_m: survey.accuracy,
          highway_route: survey.highwayRoute,
          section_name: survey.sectionName,
          chainage_from_km: survey.chainageFromKm,
          chainage_to_km: survey.chainageToKm,
          surveyor_name: user.name,
          vegetation_status: survey.vegetationStatus,
          sadc_sign_compliant: survey.sadcCompliant,
          props: survey.props,
          photos: uploadedPhotos,
          notes: survey.notes,
          captured_at: survey.capturedAt,
        },
      });
      if (!error)
        await db.surveys.update(survey.id, {
          state: "synced",
          lastError: undefined,
        });
      else await db.surveys.update(survey.id, { lastError: error.message });
    }
    await refresh();
    setSyncing(false);
  };
  const remove = async (id: string): Promise<void> => {
    await db.surveys.delete(id);
    await refresh();
  };
  return (
    <section>
      <div className="page-intro">
        <div>
          <span className="eyebrow">WORK QUEUE</span>
          <h1>Survey queue</h1>
          <p>Review drafts and send completed work.</p>
        </div>
        <div className="round-icon">
          <UploadCloud size={19} />
        </div>
      </div>
      <div className="queue-tabs">
        <button
          className={tab === "draft" ? "active" : ""}
          onClick={() => setTab("draft")}
        >
          In-progress drafts{" "}
          <span>
            {surveys.filter((survey) => survey.state === "draft").length}
          </span>
        </button>
        <button
          className={tab === "queued" ? "active" : ""}
          onClick={() => setTab("queued")}
        >
          Sync queue{" "}
          <span>
            {surveys.filter((survey) => survey.state === "queued").length}
          </span>
        </button>
      </div>
      {tab === "queued" && (
        <button
          className="primary-button wide sync-button"
          disabled={!online || syncing || !items.length}
          onClick={() => void sync()}
        >
          {syncing ? (
            <RefreshCw className="spin" size={17} />
          ) : (
            <UploadCloud size={17} />
          )}
          {!online
            ? "Connect to upload"
            : syncing
              ? "Uploading…"
              : "Upload to server"}
        </button>
      )}
      <div className="queue-list">
        {items.length ? (
          items.map((survey) => (
            <div className="queue-item" key={survey.id}>
              <div className="queue-thumb">
                {survey.geometry?.type === "LineString" ? (
                  <Route size={19} />
                ) : (
                  <MapPin size={19} />
                )}
              </div>
              <div>
                <strong>{survey.assetType.split("_").join(" ")}</strong>
                <span>
                  {survey.highwayRoute || "Unnamed route"} ·{" "}
                  {formatDate(survey.capturedAt)}
                </span>
                {survey.lastError && (
                  <small className="error-text">
                    Upload failed — try again
                  </small>
                )}
              </div>
              <button className="row-action" onClick={() => onEdit(survey)}>
                <Pencil size={15} />
              </button>
              <button
                className="row-action danger"
                onClick={() => void remove(survey.id)}
              >
                <Trash2 size={15} />
              </button>
              <span className={`state-tag ${survey.state}`}>
                {survey.state === "queued" ? "Ready" : "Draft"}
              </span>
            </div>
          ))
        ) : (
          <div className="empty-state">
            <div className="empty-icon">
              <Check size={24} />
            </div>
            <h2>
              {tab === "draft"
                ? "No in-progress drafts"
                : "Sync queue is clear"}
            </h2>
            <p>
              {tab === "draft"
                ? "Saved drafts that need more detail will appear here."
                : "Completed surveys ready to upload will appear here."}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function ProgressScreen({
  surveys,
  online,
  user,
}: {
  surveys: SurveyRecord[];
  online: boolean;
  user: SessionUser;
}) {
  const [showList, setShowList] = useState(true);
  const synced = surveys.filter((survey) => survey.state === "synced").length;
  const onMap = surveys.filter((survey) => survey.geometry).length;
  const roadKm = surveys.reduce(
    (total, survey) =>
      survey.geometry?.type === "LineString"
        ? total + lineLength(survey.geometry.coordinates as number[][]) / 1000
        : total,
    0,
  );
  return (
    <section>
      <div className="page-intro">
        <div>
          <span className="eyebrow">MY PROGRESS</span>
          <h1>Survey progress</h1>
          <p>
            {user.name} · {online ? "Last sync available" : "Offline view"}
          </p>
        </div>
        <button
          className="round-icon"
          onClick={() => window.location.reload()}
          aria-label="Refresh"
        >
          <RefreshCw size={18} />
        </button>
      </div>
      <div className="stat-grid progress-stats four">
        <div className="stat-card">
          <span className="stat-label">Total</span>
          <strong>{surveys.length}</strong>
          <small>All records</small>
        </div>
        <div className="stat-card">
          <span className="stat-label">On map</span>
          <strong>{onMap}</strong>
          <small>Located assets</small>
        </div>
        <div className="stat-card">
          <span className="stat-label">Road KM</span>
          <strong>{roadKm.toFixed(1)}</strong>
          <small>Recorded lines</small>
        </div>
        <div className="stat-card accent">
          <span className="stat-label">Synced</span>
          <strong>{synced}</strong>
          <small>Uploaded</small>
        </div>
      </div>
      <ProgressMap surveys={surveys} />
      <div className="map-legend">
        <span>
          <i className="green-dot" />
          Synced
        </span>
        <span>
          <i className="blue-dot" />
          Queued
        </span>
        <span>
          <i className="orange-dot" />
          Draft
        </span>
      </div>
      <button className="list-toggle" onClick={() => setShowList(!showList)}>
        {showList ? "Hide" : "Show"} survey list ({surveys.length})
        <ChevronRight size={15} className={showList ? "rotate" : ""} />
      </button>
      {showList &&
        (surveys.length ? (
          <div className="progress-list">
            {surveys.map((survey) => (
              <div key={survey.id}>
                <div className="list-status" data-state={survey.state} />
                <div>
                  <strong>{survey.assetType.split("_").join(" ")}</strong>
                  <span>
                    {survey.highwayRoute || "Unnamed route"} ·{" "}
                    {formatDate(survey.capturedAt)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state compact">
            <h2>No surveys on this device</h2>
            <p>Start a new survey to see your progress here.</p>
          </div>
        ))}
    </section>
  );
}
function lineLength(points: number[][]): number {
  let total = 0;
  for (let index = 1; index < points.length; index += 1) {
    const a = points[index - 1];
    const b = points[index];
    const lat = (((a[1] + b[1]) / 2) * Math.PI) / 180;
    const dx = (b[0] - a[0]) * Math.cos(lat) * 111320;
    const dy = (b[1] - a[1]) * 110540;
    total += Math.sqrt(dx * dx + dy * dy);
  }
  return total;
}
function ProgressMap({ surveys }: { surveys: SurveyRecord[] }) {
  const mapRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!mapRef.current) return;
    const map = L.map(mapRef.current, { zoomControl: false }).setView(
      [-20.16, 30.0],
      12,
    );
    L.control.zoom({ position: "topright" }).addTo(map);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
    }).addTo(map);
    const layers: L.Layer[] = [];
    surveys.forEach((survey) => {
      const color =
        survey.state === "synced"
          ? "#4b9a57"
          : survey.state === "queued"
            ? "#3f78bc"
            : "#db9b3e";
      if (survey.geometry?.type === "Point") {
        const coordinates = survey.geometry.coordinates as number[];
        layers.push(
          L.circleMarker([coordinates[1], coordinates[0]], {
            radius: 7,
            color,
            fillColor: color,
            fillOpacity: 0.88,
          })
            .bindTooltip(survey.assetType.split("_").join(" "))
            .addTo(map),
        );
      } else if (survey.geometry?.type === "LineString") {
        const coordinates = (survey.geometry.coordinates as number[][]).map(
          (point) => [point[1], point[0]] as [number, number],
        );
        layers.push(
          L.polyline(coordinates, { color, weight: 5 })
            .bindTooltip(survey.assetType.split("_").join(" "))
            .addTo(map),
        );
      }
    });
    return () => {
      layers.forEach((layer) => layer.remove());
      map.remove();
    };
  }, [surveys]);
  return (
    <div className="real-map" ref={mapRef}>
      <div className="map-offline-label">
        <MapPin size={14} />{" "}
        {surveys.length ? "Survey locations" : "No surveyed locations yet"}
      </div>
    </div>
  );
}

function SettingsScreen({
  user,
  surveyorName,
  accuracyLimit,
  surveyCount,
  saveSetting,
  setSurveyorName,
  setAccuracyLimit,
  onSignOut,
}: {
  user: SessionUser;
  surveyorName: string;
  accuracyLimit: number;
  surveyCount: number;
  saveSetting: (key: string, value: string) => Promise<void>;
  setSurveyorName: (value: string) => void;
  setAccuracyLimit: (value: number) => void;
  onSignOut: () => void;
}) {
  const [saved, setSaved] = useState(false);
  const saveProfile = async (): Promise<void> => {
    await saveSetting("surveyorName", surveyorName);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  };
  return (
    <section>
      <div className="page-intro">
        <div>
          <span className="eyebrow">PREFERENCES</span>
          <h1>Settings</h1>
          <p>Personalize your field workflow.</p>
        </div>
        <div className="round-icon">
          <SlidersHorizontal size={19} />
        </div>
      </div>
      <div className="settings-card">
        <div className="settings-profile">
          <div className="avatar large">{user.name.slice(0, 1)}</div>
          <div>
            <strong>{user.name}</strong>
            <span>{user.email}</span>
            <small className="role-badge">{user.role}</small>
          </div>
        </div>
      </div>
      <div className="settings-card">
        <div className="settings-heading">
          <SettingsIcon size={17} />
          <div>
            <h2>Surveyor profile</h2>
            <p>Saved locally and used to prefill new forms.</p>
          </div>
        </div>
        <label>
          Default surveyor name
          <input
            value={surveyorName}
            onChange={(event) => setSurveyorName(event.target.value)}
            placeholder="Use your display name"
          />
        </label>
        <button
          className="secondary-button save-profile"
          onClick={() => void saveProfile()}
        >
          {saved ? (
            <>
              <Check size={15} /> Saved
            </>
          ) : (
            "Save profile"
          )}
        </button>
      </div>
      <div className="settings-card">
        <div className="settings-heading">
          <Crosshair size={17} />
          <div>
            <h2>GPS telemetry settings</h2>
            <p>Strict accuracy prevents weak locations from being queued.</p>
          </div>
        </div>
        <div className="range-label">
          <span>Strict accuracy limit</span>
          <strong>≤{accuracyLimit.toFixed(1)} m</strong>
        </div>
        <input
          className="range"
          type="range"
          min="1"
          max="20"
          step="0.5"
          value={accuracyLimit}
          onChange={(event) => {
            const value = Number(event.target.value);
            setAccuracyLimit(value);
            void saveSetting("accuracyLimit", String(value));
          }}
        />
        <div className="range-scale">
          <span>1 m precise</span>
          <span>20 m broad</span>
        </div>
      </div>
      <div className="settings-card">
        <div className="settings-row">
          <div className="settings-leading">
            <div className="settings-icon">
              <Layers3 size={17} />
            </div>
            <div>
              <strong>Local draft queue</strong>
              <span>Survey records stored on this device</span>
            </div>
          </div>
          <b>{surveyCount} surveys</b>
        </div>
        <div className="settings-row">
          <div className="settings-leading">
            <div className="settings-icon green">
              <Cloud size={17} />
            </div>
            <div>
              <strong>Storage protected</strong>
              <span>Offline data is saved automatically</span>
            </div>
          </div>
          <span className="good-label">Active</span>
        </div>
      </div>
      <button className="signout-button" onClick={onSignOut}>
        <LogOut size={17} />
        Sign out
      </button>
      <p className="version-label">
        App Version: ChixyCollect v2.0.0
        <br />
        Developed by the Zimbabwe National Geospatial and Space Agency (ZINGSA)
      </p>
    </section>
  );
}

export default App;
