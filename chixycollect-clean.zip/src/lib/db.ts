import Dexie, { type Table } from 'dexie';

export type SurveyState = 'draft' | 'queued' | 'synced';
export type Geometry = { type: 'Point' | 'LineString'; coordinates: number[] | number[][] };

export interface SurveyPhoto { id: string; dataUrl: string; name: string; }

export interface SurveyRecord {
  id: string;
  assetType: string;
  state: SurveyState;
  highwayRoute: string;
  sectionName: string;
  surveyorName: string;
  vegetationStatus: string;
  sadcCompliant: string;
  props: Record<string, string | number | string[]>;
  notes: string;
  geometry: Geometry | null;
  accuracy: number | null;
  capturedAt: string;
  photos: SurveyPhoto[];
  collectionMode?: string;
  snapping?: boolean;
  chainageFromKm?: number;
  chainageToKm?: number;
  lastError?: string;
}

class SurveyDatabase extends Dexie {
  surveys!: Table<SurveyRecord, string>;
  settings!: Table<{ key: string; value: string }, string>;

  constructor() {
    super('motid-collect');
    this.version(2).stores({ surveys: 'id,state,assetType,capturedAt', settings: 'key' });
  }
}

export const db = new SurveyDatabase();
