/*
# Create Mutare Asset Survey foundation

1. New tables
- `profiles`: signed-in surveyor names and roles.
- `lookup_options`: editable dropdown choices shared by the survey team.
- `survey_features`: submitted point and line surveys with GeoJSON-derived geometry.
2. Supporting behavior
- Creates the new-user profile trigger, idempotent survey upload RPC, GeoJSON export RPC, and line-length trigger.
- Creates the private `survey-photos` storage bucket.
3. Security
- Enables row-level security on every application table.
- Surveyors can only read and write their own surveys; supervisors and admins can review all surveys.
- Admin-only changes are split into separate read, insert, update, and delete policies.
- Photo paths must start with the signed-in user's ID.
4. Important notes
- Survey IDs are supplied by the phone so retries are safe.
- Geometry is stored in WGS84 (EPSG:4326).
*/

CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  role text NOT NULL DEFAULT 'surveyor' CHECK (role IN ('surveyor','supervisor','admin'))
);

CREATE OR REPLACE FUNCTION handle_new_user() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();

CREATE OR REPLACE FUNCTION app_role() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM profiles WHERE id = auth.uid()
$$;

CREATE TABLE IF NOT EXISTS lookup_options (
  list_key text NOT NULL,
  value text NOT NULL,
  sort int NOT NULL DEFAULT 0,
  PRIMARY KEY (list_key, value)
);

CREATE TABLE IF NOT EXISTS survey_features (
  id uuid PRIMARY KEY,
  asset_type text NOT NULL,
  geom geometry(Geometry, 4326) NOT NULL,
  gps_accuracy_m real,
  highway_route text,
  section_name text,
  chainage_from_km numeric,
  chainage_to_km numeric,
  surveyor_name text NOT NULL,
  surveyor_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id),
  vegetation_status text,
  sadc_sign_compliant text,
  length_m numeric,
  props jsonb NOT NULL DEFAULT '{}',
  photos jsonb NOT NULL DEFAULT '[]',
  notes text,
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','approved','rejected')),
  captured_at timestamptz NOT NULL,
  synced_at timestamptz NOT NULL DEFAULT now(),
  reviewed_by uuid,
  reviewed_at timestamptz,
  review_note text,
  CONSTRAINT valid_geom CHECK (ST_IsValid(geom)),
  CONSTRAINT geom_matches_type CHECK (
    (asset_type IN ('sealed_road','gravel_road','earth_road') AND GeometryType(geom) = 'LINESTRING')
    OR (asset_type NOT IN ('sealed_road','gravel_road','earth_road') AND GeometryType(geom) = 'POINT')
  )
);

CREATE INDEX IF NOT EXISTS sf_geom_idx ON survey_features USING GIST (geom);
CREATE INDEX IF NOT EXISTS sf_type_idx ON survey_features (asset_type);
CREATE INDEX IF NOT EXISTS sf_status_idx ON survey_features (status);
CREATE INDEX IF NOT EXISTS sf_user_idx ON survey_features (surveyor_id);

CREATE OR REPLACE FUNCTION set_line_length() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF GeometryType(NEW.geom) = 'LINESTRING' THEN NEW.length_m := ST_Length(NEW.geom::geography); END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_set_line_length ON survey_features;
CREATE TRIGGER trg_set_line_length BEFORE INSERT OR UPDATE ON survey_features
FOR EACH ROW EXECUTE FUNCTION set_line_length();

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE lookup_options ENABLE ROW LEVEL SECURITY;
ALTER TABLE survey_features ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profiles_read ON profiles;
CREATE POLICY profiles_read ON profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR app_role() IN ('supervisor','admin'));
DROP POLICY IF EXISTS profiles_update ON profiles;

DROP POLICY IF EXISTS lookup_read ON lookup_options;
CREATE POLICY lookup_read ON lookup_options FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS lookup_insert_admin ON lookup_options;
CREATE POLICY lookup_insert_admin ON lookup_options FOR INSERT TO authenticated WITH CHECK (app_role() = 'admin');
DROP POLICY IF EXISTS lookup_update_admin ON lookup_options;
CREATE POLICY lookup_update_admin ON lookup_options FOR UPDATE TO authenticated
  USING (app_role() = 'admin') WITH CHECK (app_role() = 'admin');
DROP POLICY IF EXISTS lookup_delete_admin ON lookup_options;
CREATE POLICY lookup_delete_admin ON lookup_options FOR DELETE TO authenticated USING (app_role() = 'admin');

DROP POLICY IF EXISTS sf_select ON survey_features;
CREATE POLICY sf_select ON survey_features FOR SELECT TO authenticated
  USING (surveyor_id = auth.uid() OR app_role() IN ('supervisor','admin'));
DROP POLICY IF EXISTS sf_insert ON survey_features;
CREATE POLICY sf_insert ON survey_features FOR INSERT TO authenticated
  WITH CHECK (surveyor_id = auth.uid());
DROP POLICY IF EXISTS sf_update ON survey_features;
CREATE POLICY sf_update ON survey_features FOR UPDATE TO authenticated
  USING ((surveyor_id = auth.uid() AND status = 'submitted') OR app_role() IN ('supervisor','admin'))
  WITH CHECK (surveyor_id = auth.uid() OR app_role() IN ('supervisor','admin'));
DROP POLICY IF EXISTS sf_delete ON survey_features;
CREATE POLICY sf_delete ON survey_features FOR DELETE TO authenticated
  USING (surveyor_id = auth.uid() OR app_role() = 'admin');

CREATE OR REPLACE FUNCTION upsert_survey(p jsonb) RETURNS void
LANGUAGE plpgsql SECURITY INVOKER AS $$
BEGIN
  INSERT INTO survey_features (id, asset_type, geom, gps_accuracy_m, highway_route, section_name,
    chainage_from_km, chainage_to_km, surveyor_name, vegetation_status, sadc_sign_compliant,
    props, photos, notes, captured_at)
  VALUES ((p->>'id')::uuid, p->>'asset_type',
    ST_SetSRID(ST_GeomFromGeoJSON(p->'geometry'), 4326), (p->>'gps_accuracy_m')::real,
    p->>'highway_route', p->>'section_name', (p->>'chainage_from_km')::numeric,
    (p->>'chainage_to_km')::numeric, p->>'surveyor_name', p->>'vegetation_status',
    p->>'sadc_sign_compliant', COALESCE(p->'props','{}'), COALESCE(p->'photos','[]'),
    p->>'notes', (p->>'captured_at')::timestamptz)
  ON CONFLICT (id) DO UPDATE SET
    geom = EXCLUDED.geom, gps_accuracy_m = EXCLUDED.gps_accuracy_m,
    highway_route = EXCLUDED.highway_route, section_name = EXCLUDED.section_name,
    chainage_from_km = EXCLUDED.chainage_from_km, chainage_to_km = EXCLUDED.chainage_to_km,
    vegetation_status = EXCLUDED.vegetation_status, sadc_sign_compliant = EXCLUDED.sadc_sign_compliant,
    props = EXCLUDED.props, photos = EXCLUDED.photos, notes = EXCLUDED.notes, synced_at = now()
  WHERE survey_features.status = 'submitted';
END $$;

CREATE OR REPLACE FUNCTION list_features_geojson(p_status text DEFAULT NULL, p_type text DEFAULT NULL)
RETURNS jsonb LANGUAGE sql STABLE SECURITY INVOKER AS $$
  SELECT jsonb_build_object('type','FeatureCollection','features',
    COALESCE(jsonb_agg(jsonb_build_object('type','Feature','id',id,
      'geometry', ST_AsGeoJSON(geom)::jsonb,
      'properties', to_jsonb(f) - 'geom')), '[]'::jsonb))
  FROM survey_features f
  WHERE (p_status IS NULL OR status = p_status) AND (p_type IS NULL OR asset_type = p_type)
$$;

INSERT INTO storage.buckets (id, name, public) VALUES ('survey-photos','survey-photos', false)
ON CONFLICT (id) DO NOTHING;
DROP POLICY IF EXISTS photos_upload ON storage.objects;
CREATE POLICY photos_upload ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'survey-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
DROP POLICY IF EXISTS photos_read ON storage.objects;
CREATE POLICY photos_read ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'survey-photos' AND ((storage.foldername(name))[1] = auth.uid()::text OR app_role() IN ('supervisor','admin')));

INSERT INTO lookup_options (list_key, value, sort) VALUES
 ('condition','Good',1),('condition','Fair',2),('condition','Poor',3),('condition','Very Poor',4),
 ('yes_no','Yes',1),('yes_no','No',2),('vegetation_status','Low',1),('vegetation_status','Medium',2),
 ('vegetation_status','High',3),('sadc_compliant','Yes (Compliant)',1),('sadc_compliant','No (Non-compliant)',2),
 ('operational','Operational',1),('operational','Not Operational',2)
ON CONFLICT DO NOTHING;