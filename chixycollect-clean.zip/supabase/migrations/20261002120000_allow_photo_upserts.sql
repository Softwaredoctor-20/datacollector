DROP POLICY IF EXISTS photos_update ON storage.objects;
CREATE POLICY photos_update ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'survey-photos' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'survey-photos' AND (storage.foldername(name))[1] = auth.uid()::text);